# Ev Kiralama Sistemi

## Proje Hakkında
Bu proje Java ve MySQL kullanılarak geliştirilmiş bir ev kiralama sistemidir. Kullanıcılar sisteme giriş yaptıktan sonra evleri listeleyebilir, şehre göre arama yapabilir ve yeni ev ekleyebilir.

## Projenin Amacı
Bu projenin amacı Java JDBC kullanarak veritabanı işlemlerini gerçekleştirmek ve nesne tabanlı programlama (OOP) mantığını uygulamaktır.

## Kullanılan Teknolojiler
- Java
- MySQL
- JDBC

## Veritabanı Yapısı

### Kullanicilar Tablosu
- user_id
- ad
- email
- sifre

### Evler Tablosu
- house_id
- baslik
- sehir
- fiyat
- aciklama
- owner_id

## Proje Özellikleri
- Kullanıcı giriş sistemi
- Tüm evleri listeleme
- Şehre göre ev arama
- Yeni ev ekleme
- MySQL veritabanı bağlantısı

## OOP Yapısı
Projede nesne tabanlı programlama kullanılmıştır.

- Ev sınıfı oluşturulmuştur
- Kullanici sınıfı oluşturulmuştur
- Constructor kullanılmıştır
- Getter ve Setter metotları kullanılmıştır
- Encapsulation uygulanmıştır

## Çalıştırma Adımları
1. MySQL üzerinde evkiralamadb veritabanı oluşturulur
2. Kullanicilar ve Evler tabloları oluşturulur
3. JDBC bağlantı bilgileri düzenlenir
4. Proje çalıştırılır
5. Konsol üzerinden email ve şifre ile giriş yapılır

## Menü Seçenekleri
1. Tüm evleri listele
2. Şehre göre ev ara
3. Ev ekle
4. Çıkış

## Not
Bu proje eğitim amaçlı geliştirilmiştir. Java JDBC ve nesne tabanlı programlama öğrenmek için hazırlanmıştır.
