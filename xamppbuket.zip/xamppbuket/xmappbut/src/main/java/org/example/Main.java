package org.example;

import javax.swing.*;
import java.sql.*;
import java.security.MessageDigest;
import java.util.ArrayList;

public class Main {

    static User currentUser;

    static Connection connect() throws Exception {
        Class.forName("com.mysql.cj.jdbc.Driver");
        return DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/OnlineEvKiralamaDB",
                "root",
                ""
        );
    }

    public static void main(String[] args) {

        JFrame f = new JFrame("Ev Kiralama Sistemi");
        f.setSize(900, 650);
        f.setLayout(null);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.setLocationRelativeTo(null);

        JTextField user = new JTextField();
        user.setBounds(20, 20, 150, 30);

        JPasswordField pass = new JPasswordField();
        pass.setBounds(180, 20, 150, 30);

        JButton register = new JButton("Kayıt");
        register.setBounds(340, 20, 100, 30);

        JButton login = new JButton("Giriş");
        login.setBounds(450, 20, 100, 30);

        JTextField houseId = new JTextField();
        houseId.setBounds(20, 70, 100, 30);

        JTextField title = new JTextField();
        title.setBounds(130, 70, 120, 30);

        JTextField city = new JTextField();
        city.setBounds(260, 70, 100, 30);

        JTextField price = new JTextField();
        price.setBounds(370, 70, 100, 30);

        JButton add = new JButton("İlan Ekle");
        add.setBounds(480, 70, 120, 30);

        JButton delete = new JButton("İlan Sil");
        delete.setBounds(610, 70, 120, 30);

        JButton buy = new JButton("Satın Al");
        buy.setBounds(20, 110, 120, 30);

        JButton rent = new JButton("Kirala");
        rent.setBounds(150, 110, 120, 30);

        JButton list = new JButton("Listele");
        list.setBounds(280, 110, 120, 30);

        JTextArea area = new JTextArea();
        area.setEditable(false);

        JScrollPane sp = new JScrollPane(area);
        sp.setBounds(20, 160, 840, 430);

        f.add(user);
        f.add(pass);
        f.add(register);
        f.add(login);
        f.add(houseId);
        f.add(title);
        f.add(city);
        f.add(price);
        f.add(add);
        f.add(delete);
        f.add(buy);
        f.add(rent);
        f.add(list);
        f.add(sp);

        f.setVisible(true);

        AuthService auth = new AuthService();
        HouseService service = new HouseService();

        register.addActionListener(e -> {
            try {
                auth.register(user.getText(), hash(new String(pass.getPassword())));
                area.setText("Kayıt başarılı");
            } catch (Exception ex) {
                area.setText(ex.getMessage());
            }
        });

        login.addActionListener(e -> {
            try {
                currentUser = auth.login(user.getText(), hash(new String(pass.getPassword())));
                if (currentUser != null) {
                    area.setText("Giriş başarılı\n\n");
                    show(service, area);
                } else {
                    area.setText("Hatalı giriş");
                }
            } catch (Exception ex) {
                area.setText(ex.getMessage());
            }
        });

        list.addActionListener(e -> {
            area.setText("");
            show(service, area);
        });

        add.addActionListener(e -> {
            try {
                service.addHouse(
                        title.getText(),
                        city.getText(),
                        Double.parseDouble(price.getText()),
                        currentUser.getId()
                );
                area.setText("İlan eklendi\n\n");
                show(service, area);
            } catch (Exception ex) {
                area.setText(ex.getMessage());
            }
        });

        delete.addActionListener(e -> {
            try {
                service.deleteHouse(Integer.parseInt(houseId.getText()), currentUser.getId());
                area.setText("İlan silindi\n\n");
                show(service, area);
            } catch (Exception ex) {
                area.setText(ex.getMessage());
            }
        });

        buy.addActionListener(e -> {
            try {
                service.buy(Integer.parseInt(houseId.getText()));
                area.setText("Satın alındı\n\n");
                show(service, area);
            } catch (Exception ex) {
                area.setText(ex.getMessage());
            }
        });

        rent.addActionListener(e -> {
            try {
                service.rent(Integer.parseInt(houseId.getText()), currentUser.getId());
                area.setText("Kiralandı\n\n");
                show(service, area);
            } catch (Exception ex) {
                area.setText(ex.getMessage());
            }
        });
    }

    static void show(HouseService service, JTextArea area) {
        try {
            for (House h : service.getAll()) {
                area.append(
                        h.getId() + " | " +
                                h.getTitle() + " | " +
                                h.getCity() + " | " +
                                h.getPrice() + " | " +
                                h.getStatus() + "\n"
                );
            }
        } catch (Exception e) {
            area.setText(e.getMessage());
        }
    }

    static String hash(String text) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] b = md.digest(text.getBytes());
            StringBuilder sb = new StringBuilder();
            for (byte x : b) sb.append(String.format("%02x", x));
            return sb.toString();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}

class User {
    private int id;
    private String username;

    public User(int id, String username) {
        this.id = id;
        this.username = username;
    }

    public int getId() {
        return id;
    }

    public String getUsername() {
        return username;
    }
}

class House {
    private int id;
    private String title;
    private String city;
    private double price;
    private String status;

    public House(int id, String title, String city, double price, String status) {
        this.id = id;
        this.title = title;
        this.city = city;
        this.price = price;
        this.status = status;
    }

    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getCity() {
        return city;
    }

    public double getPrice() {
        return price;
    }

    public String getStatus() {
        return status;
    }
}

class AuthService {

    public User login(String u, String p) throws Exception {
        Connection c = DriverManager.getConnection("jdbc:mysql://localhost:3306/OnlineEvKiralamaDB","root","");
        PreparedStatement ps = c.prepareStatement("SELECT * FROM Users WHERE Username=? AND PasswordHash=?");
        ps.setString(1, u);
        ps.setString(2, p);
        ResultSet rs = ps.executeQuery();
        if (rs.next()) return new User(rs.getInt("UserID"), rs.getString("Username"));
        return null;
    }

    public void register(String u, String p) throws Exception {
        Connection c = DriverManager.getConnection("jdbc:mysql://localhost:3306/OnlineEvKiralamaDB","root","");
        PreparedStatement ps = c.prepareStatement("INSERT INTO Users(Username,PasswordHash) VALUES(?,?)");
        ps.setString(1, u);
        ps.setString(2, p);
        ps.executeUpdate();
    }
}

class HouseService {

    Connection c;

    public HouseService() {
        try {
            c = DriverManager.getConnection("jdbc:mysql://localhost:3306/OnlineEvKiralamaDB","root","");
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public ArrayList<House> getAll() throws Exception {
        ResultSet rs = c.createStatement().executeQuery("SELECT * FROM Houses");
        ArrayList<House> list = new ArrayList<>();
        while (rs.next()) {
            list.add(new House(
                    rs.getInt("HouseID"),
                    rs.getString("Title"),
                    rs.getString("City"),
                    rs.getDouble("Price"),
                    rs.getString("Status")
            ));
        }
        return list;
    }

    public void addHouse(String title, String city, double price, int ownerId) throws Exception {
        PreparedStatement ps = c.prepareStatement(
                "INSERT INTO Houses(Title,City,Price,Status,OwnerID) VALUES(?,?,?,?,?)"
        );
        ps.setString(1, title);
        ps.setString(2, city);
        ps.setDouble(3, price);
        ps.setString(4, "AVAILABLE");
        ps.setInt(5, ownerId);
        ps.executeUpdate();
    }

    public void deleteHouse(int id, int ownerId) throws Exception {
        PreparedStatement ps = c.prepareStatement(
                "DELETE FROM Houses WHERE HouseID=? AND OwnerID=?"
        );
        ps.setInt(1, id);
        ps.setInt(2, ownerId);
        ps.executeUpdate();
    }

    public void buy(int id) throws Exception {
        PreparedStatement ps = c.prepareStatement(
                "UPDATE Houses SET Status='SOLD' WHERE HouseID=?"
        );
        ps.setInt(1, id);
        ps.executeUpdate();
    }

    public void rent(int id, int userId) throws Exception {
        PreparedStatement ps = c.prepareStatement(
                "INSERT INTO Rentals(HouseID,UserID) VALUES(?,?)"
        );
        ps.setInt(1, id);
        ps.setInt(2, userId);
        ps.executeUpdate();
    }
}